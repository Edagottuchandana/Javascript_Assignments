const randomNumber=Math.random();
console.log(randomNumber);


//  TO GET RANDOM NUMBER BETWEEN 1 TO  10
//  WE HAVE THE CODE
const rand=Math.floor(Math.random()*10)+1;
console.log(rand)
alert(rand);;