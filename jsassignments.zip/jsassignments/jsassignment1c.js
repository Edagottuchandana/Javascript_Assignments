document.write("Hello World");
