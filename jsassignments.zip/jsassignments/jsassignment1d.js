const userInput = parseInt(prompt('Enter a number:'));
if (userInput % 2 === 0) {
  console.log('The number is even.');
  alert("The number is Even");
} else {
  console.log('The number is odd.');
  alert("The number is odd");
}
