
const username = prompt('Enter your username:');
const address = prompt('Enter your address:');

const usernameLength = username.length;
const addressLength = address.length;
const uppercaseUsername = username.toUpperCase();
const uppercaseAddress = address.toUpperCase();
console.log('Username Length:', usernameLength);
console.log('Address Length:', addressLength);
console.log('Uppercase Username:', uppercaseUsername);
console.log('Uppercase Address:', uppercaseAddress);
