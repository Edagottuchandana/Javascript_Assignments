const variable1 = 10;                         
const variable2 = 'Hello,world!';            
const variable3 = true;                       
const variable4 = ['apple','banana','pear']; 
const variable5 = { name:'John',age: 30 };  

console.log(typeof(variable1));  
console.log(typeof(variable2));  
console.log(typeof(variable3));  
console.log(typeof(variable4));  
console.log(typeof(variable5));  
